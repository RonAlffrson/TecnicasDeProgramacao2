package tratamento_de_excecoes.operacao_matematica.op_binarias;

import tratamento_de_excecoes.operacao_matematica.OperacaoMatematica;

public abstract class OperacaoBinaria extends OperacaoMatematica {
    protected double operando1, operando2;
}
