package tratamento_de_excecoes.operacao_matematica.op_unarias;

import tratamento_de_excecoes.operacao_matematica.OperacaoMatematica;

public abstract class OperacaoUnaria extends OperacaoMatematica {
    public double operando;
}
