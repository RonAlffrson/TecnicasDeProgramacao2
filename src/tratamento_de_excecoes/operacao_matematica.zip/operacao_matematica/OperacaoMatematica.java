package tratamento_de_excecoes.operacao_matematica;

public abstract class OperacaoMatematica {
    public abstract double calcular();
}
